package classProject;

import java.util.ArrayList;

public class Customer {
	
	private static ArrayList<Customer> customerList = new ArrayList<Customer>();
	private String firstName;
	private String lastName;
	private String email;
	private String password;
	private boolean gender; // false - Male, true - Female
	private int age; // value of 25 -> 25 or under || value of 45 -> 26 to 45 || value of 60 -> 46 to 60 || value of 61 -> over 60
	
	public Customer() {
		firstName = "";
		lastName = "";
		email = "";
		password = "";
		gender = false;
		age = 0;
	}
	public Customer(String e, String p, boolean g, int a) {
		firstName = "Anonymous";
		lastName = "Anonymous";
		email = e;
		password = p;
		gender = g;
		age = a;
	}
	public Customer(String fn, String ln, String e, String p, boolean g, int a) {
		firstName = fn;
		lastName = ln;
		email = e;
		password = p;
		gender = g;
		age = a;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getGender() {
		if(gender) {
			return "Female";
		} else {
			return "Male";
		}
	}
	public void setGender(boolean gender) {
		this.gender = gender;
	}
	public String getAgeRange() {
		if(age == 25) {
			return "Under 25";
		} else if(age == 45) {
			return "26 to 45";
		} else if(age == 60) {
			return "46 to 60";
		} else if(age == 61) {
			return "Over 60";
		} else {
			return "ERROR";
		}
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	// TODO DATABASE STUFF will replace the below methods ---
	
	public static ArrayList<Customer> getList() {
		return customerList;
	}
	public static void addCustomerToList(Customer customer) {
		customerList.add(customer);
	}
	
	public static void printList() {
		for(int i = 0; i < customerList.size(); i++) {
			System.out.println(customerList.get(i));
		}
	}
	
	// TODO DATABASE STUFF will replace the above methods ---
	
	public String toString() {
		return getFirstName() + " " + getLastName() + " " + getEmail() + " " + getGender() + " " + getAgeRange();
	}
}
