package classProject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

@SuppressWarnings("serial")
public class ProjectLoginPage extends JFrame{

	JPanel loginPanel;
	
	public ProjectLoginPage() {
		// SETUP
		this.setSize(500,200);
		this.setLocation(800, 500);
		this.setResizable(true);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle("Login - SWGOHUtils");
		loginPanel = new JPanel();
		loginPanel.setLayout(new GridBagLayout());
		add(loginPanel);
		// END SETUP
		
		JPanel emailPanel = new JPanel(new GridBagLayout());
		emailPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		JLabel emailLabel = new JLabel("Email: ");
		JTextField email = new JTextField(30);
		
		JPanel pwdPanel = new JPanel(new GridBagLayout());
		pwdPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		JLabel pwdLabel = new JLabel("Password: ");
		JPasswordField pwd = new JPasswordField(30);
		pwd.setEchoChar('*');
		
		JButton login = new JButton("Login");
		login.addActionListener(
			new ActionListener()
			{	
				public void actionPerformed(ActionEvent e) {
					login(email.getText(), new String(pwd.getPassword()));
				}
			}
		);
		
		addComp(loginPanel, emailPanel, 0, 0, 3, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(emailPanel, emailLabel, 0, 0, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(emailPanel, email, 1, 0, 2, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		
		addComp(loginPanel, pwdPanel, 0, 1, 3, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(pwdPanel, pwdLabel, 0, 0, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(pwdPanel, pwd, 1, 0, 2, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		
		addComp(loginPanel, login, 1, 2, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		
		
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public static void main(String[] args) {
		new ProjectLoginPage();
	}

	static void login(String email, String pwd) {
		// TODO Database stuff
	}
	
	private void addComp(JPanel thePanel, JComponent comp, int colP, int rowP, 
			int w, int h, int place, int stretch)
	{
		GridBagConstraints gridC = new GridBagConstraints();
		gridC.gridx = colP;		// column position
		gridC.gridy = rowP;		// row position
		gridC.gridwidth = w;		// # of columns it spans
		gridC.gridheight = h;	// # of rows it spans
		gridC.insets = new Insets(5,5,5,5);	// spaces between cols and rows
		gridC.anchor = place;	// position in cell
		gridC.fill = stretch;	// ????
		thePanel.add(comp, gridC);
	}
}
