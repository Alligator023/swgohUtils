package classProject;

public class ProjectRunner {

	public static void main(String[] args) {
		new ProjectMainPage();
	}

}
