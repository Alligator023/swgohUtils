package classProject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ProjectAccountPage extends JFrame{

	JPanel accountPanel;
	private int ageSend;
	private boolean genderSend;
	private boolean readyToSend;
	
	JLabel firstName;
	JLabel lastName;
	JLabel email;
	JLabel password;
	JLabel confirmPwd;
	JTextField enterFirstName;
	JTextField enterLastName;
	JTextField enterEmail;
	JTextField enterPwd;
	JTextField enterConfirmPwd;
	JPanel gender;
	JPanel age;
	JRadioButton male;
	JRadioButton female;
	JRadioButton under25;
	JRadioButton to45;
	JRadioButton to60;
	JRadioButton over60;
	JButton createAccount;
	
	public ProjectAccountPage(JFrame original) {
		// SETUP
		this.setSize(500,450);
		this.setLocation(800, 500);
		this.setResizable(true);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle("Create An Account - "); // TODO Title the Window with the Project Name
		ageSend = 0;
		genderSend = false;
		readyToSend = false;
		accountPanel = new JPanel();
		accountPanel.setLayout(new GridBagLayout());
		add(accountPanel);
		// END SETUP
			
		// BEGIN NAME
		JPanel namePanel = new JPanel(new GridBagLayout());
		namePanel.setBorder(BorderFactory.createLineBorder(Color.black));
		firstName = new JLabel("First Name:");
		enterFirstName = new JTextField(30);
		JPanel lastNamePanel = new JPanel(new GridBagLayout());
		lastNamePanel.setBorder(BorderFactory.createLineBorder(Color.black));
		lastName = new JLabel("Last Name:");
		enterLastName = new JTextField(30);
		// END NAME
		
		// BEGIN GENDER - COMPLETED
		gender = new JPanel(new GridBagLayout());
		gender.setBorder(BorderFactory.createLineBorder(Color.black));
		JLabel genderLabel = new JLabel("Gender | ");
		JLabel maleLabel = new JLabel("Male: ");
		male = new JRadioButton();
		male.addActionListener(
			new ActionListener()
			{	
				public void actionPerformed(ActionEvent e) {
					female.setSelected(false);
					genderSend = false;
				}
				
			}
		);
		JLabel femaleLabel = new JLabel("Female: ");
		female = new JRadioButton();
		female.addActionListener(
				new ActionListener()
				{	
					public void actionPerformed(ActionEvent e) {
						male.setSelected(false);
						genderSend = true;
					}
					
				}
			);
		// END GENDER
		
		// BEGIN AGE - COMPLETED
		age = new JPanel(new GridBagLayout());
		age.setBorder(BorderFactory.createLineBorder(Color.black));
		JLabel ageLabel = new JLabel("Age | ");
		JLabel under25label = new JLabel("Under 25: ");
		under25 = new JRadioButton();
		under25.addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e) {
						to45.setSelected(false);
						to60.setSelected(false);
						over60.setSelected(false);
						ageSend = 25;
					}
				}
			);
		JLabel to45label = new JLabel("26 to 45: ");
		to45 = new JRadioButton();
		to45.addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e) {
						under25.setSelected(false);
						to60.setSelected(false);
						over60.setSelected(false);
						ageSend = 45;
					}
				}
			);
		JLabel to60label = new JLabel("46 to 60: ");
		to60 = new JRadioButton();
		to60.addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e) {
						to45.setSelected(false);
						under25.setSelected(false);
						over60.setSelected(false);
						ageSend = 60;
					}
				}
			);
		JLabel over60label = new JLabel("Over 60: ");
		over60 = new JRadioButton();
		over60.addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e) {
						to45.setSelected(false);
						to60.setSelected(false);
						under25.setSelected(false);
						ageSend = 61;
					}
				}
			);
		// END AGE
		
		// BEGIN EMAIL/PSWD
		JPanel emailPanel = new JPanel(new GridBagLayout());
		emailPanel.setBorder(BorderFactory.createLineBorder(Color.black));
		email = new JLabel("Email Address:");
		enterEmail = new JTextField(30);
		
		JPanel pwdPanel = new JPanel(new GridBagLayout());
		pwdPanel.setBorder(BorderFactory.createLineBorder(Color.black));
		password = new JLabel("Password:");
		enterPwd = new JTextField(30);
		
		JPanel confirmPwdPanel = new JPanel(new GridBagLayout());
		confirmPwdPanel.setBorder(BorderFactory.createLineBorder(Color.black));
		confirmPwd = new JLabel("Confirm Password:");
		enterConfirmPwd = new JTextField(30);
		// END EMAIL/PSWD
		
		JPanel createPanel = new JPanel(new GridBagLayout());
		createAccount = new JButton("Create Account");
		createAccount.addActionListener(
			new ActionListener()
			{	
				public void actionPerformed(ActionEvent e) {
					updateReady();
					if(readyToSend) {
						Customer c = new Customer(enterFirstName.getText(), enterLastName.getText(), enterEmail.getText(), enterPwd.getText(), genderSend, ageSend);
						Customer.addCustomerToList(c);
						Customer.printList();
						original.setVisible(true);
						
					} else {
						System.out.println("ERROR! Incomplete Form!");
						System.exit(0);
					}
					setVisible(false);
				}
				
			}
		);
		
			addComp(accountPanel, namePanel, 0, 0, 3, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(namePanel, firstName, 0, 0, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(namePanel, enterFirstName, 1, 0, 2, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
			addComp(accountPanel, lastNamePanel, 0, 1, 3, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(lastNamePanel, lastName, 0, 0, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(lastNamePanel, enterLastName, 1, 0, 2, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
			addComp(accountPanel, gender, 0, 2, 3, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(gender, genderLabel, 0, 0, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(gender, maleLabel, 1, 0, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(gender, male, 2, 0, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(gender, femaleLabel, 3, 0, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(gender, female, 4, 0, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
			addComp(accountPanel, age, 0, 3, 3, 2, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(age, ageLabel, 0, 0, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(age, under25label, 1, 0, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(age, under25, 2, 0, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(age, to45label, 3, 0, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(age, to45, 4, 0, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(age, to60label, 1, 1, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(age, to60, 2, 1, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(age, over60label, 3, 1, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(age, over60, 4, 1, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
			addComp(accountPanel, emailPanel, 0, 5, 3, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(emailPanel, email, 0, 0, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(emailPanel, enterEmail, 1, 0, 2, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
			addComp(accountPanel, pwdPanel, 0, 6, 3, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(pwdPanel, password, 0, 0, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(pwdPanel, enterPwd, 1, 0, 2, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
			addComp(accountPanel, confirmPwdPanel, 0, 7, 3, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(confirmPwdPanel, confirmPwd, 0, 0, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(confirmPwdPanel, enterConfirmPwd, 1, 0, 2, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
			addComp(accountPanel, createPanel, 0, 8, 3, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		addComp(createPanel, createAccount, 0, 0, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE);
		
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	
	public static void main(String[] args) {
		new ProjectAccountPage(null);
	}
	
	private void updateReady() {
		if(enterFirstName.getText().equals("") || enterLastName.getText().equals("") || enterEmail.getText().equals("") || enterPwd.getText().equals("") || (!enterConfirmPwd.getText().equals(enterPwd.getText())) || (!genderSelected()) || (!ageSelected())) {
			readyToSend = false;
		} else {
			readyToSend = true;
		}
	}
	private boolean genderSelected() {
		if(male.isSelected() || female.isSelected()) {
			return true;
		} else {
			return false;
		}
	}
	private boolean ageSelected() {
		if(under25.isSelected() || to45.isSelected() || to60.isSelected() || over60.isSelected()) {
			return true;
		} else {
			return false;
		}
	}
	
	private void addComp(JPanel thePanel, JComponent comp, int colP, int rowP, 
			int w, int h, int place, int stretch)
	{
		GridBagConstraints gridC = new GridBagConstraints();
		gridC.gridx = colP;		// column position
		gridC.gridy = rowP;		// row position
		gridC.gridwidth = w;		// # of columns it spans
		gridC.gridheight = h;	// # of rows it spans
		gridC.insets = new Insets(5,5,5,5);	// spaces between cols and rows
		gridC.anchor = place;	// position in cell
		gridC.fill = stretch;	// ????
		thePanel.add(comp, gridC);
	}

}
