package classProject;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

public class ProjectMainPage extends JFrame{

	JPanel mainPanel;
	
	public ProjectMainPage() {
		// SETUP
		this.setSize(200,200);
		this.setLocation(800, 500);
		this.setResizable(true);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle("NEEDS A TITLE");
		this.setIconImage(new ImageIcon(getClass().getResource("swgoh.png")).getImage());;
		this.setBackground(Color.black);
		JFrame thisFrame = this;
		// END SETUP
		
		mainPanel = new JPanel();
		mainPanel.setLayout(new GridBagLayout());
		add(mainPanel);
		
		JButton login = new JButton();
		login.addActionListener(
			new ActionListener()
			{	
				public void actionPerformed(ActionEvent e) {
					new ProjectLoginPage();
					setVisible(false);
				}
				
			}
		);
		mainPanel.add(login);
		JButton createAccount = new JButton();
		createAccount.addActionListener(
			new ActionListener()
			{	
				public void actionPerformed(ActionEvent e) {
					new ProjectAccountPage(thisFrame);
					setVisible(false);
				}
				
			}
		);
		mainPanel.add(createAccount);
		
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new ProjectMainPage();
	}
	
	private void addComp(JPanel thePanel, JComponent comp, int colP, int rowP, 
			int w, int h, int place, int stretch)
	{
		GridBagConstraints gridC = new GridBagConstraints();
		gridC.gridx = colP;		// column position
		gridC.gridy = rowP;		// row position
		gridC.gridwidth = w;		// # of columns it spans
		gridC.gridheight = h;	// # of rows it spans
		gridC.insets = new Insets(5,5,5,5);	// spaces between cols and rows
		gridC.anchor = place;	// position in cell
		gridC.fill = stretch;	// ????
		thePanel.add(comp, gridC);
	}
	
	public JFrame returnFrame() {
		return this;
	}

}
