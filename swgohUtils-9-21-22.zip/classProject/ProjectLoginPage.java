package classProject;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

public class ProjectLoginPage extends JFrame{

	JPanel loginPanel;
	
	public ProjectLoginPage() {
		// SETUP
		this.setSize(200,200);
		this.setLocation(800, 500);
		this.setResizable(true);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle("NEEDS A TITLE");
		// END SETUP
		
		loginPanel = new JPanel();
		loginPanel.setLayout(new GridBagLayout());
		add(loginPanel);
			
		JButton login = new JButton();
		loginPanel.add(login);
		JButton createAccount = new JButton();
		loginPanel.add(createAccount);
				
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new ProjectLoginPage();
	}

}
